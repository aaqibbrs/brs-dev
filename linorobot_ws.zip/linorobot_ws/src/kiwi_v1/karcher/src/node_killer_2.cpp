#include "ros/ros.h"
#include "sensor_msgs/LaserScan.h"
#include <iostream>
#include <string.h>
#include <fstream>
#include <time.h>

#define RAD2DEG(x) ((x)*180./M_PI)

//creating global object
 time_t start, end;


//callback function
void scanCallback(const sensor_msgs::LaserScan::ConstPtr& scan)
{  std::string z; //initialize variable string 
	 
    int count = scan->scan_time / scan->time_increment;
//    ROS_INFO("I heard a laser scan %s[%d]:", scan->header.frame_id.c_str(), count);
    float a=RAD2DEG(scan->angle_min)+179, b=RAD2DEG(scan->angle_max)+179;
  //  ROS_INFO("angle_range, %f, %f", a, b);
   
   for(int i = 0; i < count; i++) {
  
  	float degree = RAD2DEG(scan->angle_min + scan->angle_increment * i)+179; //changing angle from 0-360
  	if(scan->intensities[i]==0) //removing error data
	        continue;
       
       //condition for printing inside range and angle
        if(scan->ranges[i]<=1 && degree>=0 && degree<=90)
	        z="right";

        if(scan->ranges[i]<=1 && degree>90 && degree<=180)
	        z="front";

        if(scan->ranges[i]<=1 && degree>=180 && degree<=270)
	        z="left";

        if(scan->ranges[i]<=1 && degree>=270 && degree<=359)
	        z="back";
	   }
  // std::cout<<"\n\n"<<z<<"\n\n"; //print
   time(&end); //end time
}


//timer function
void timer(){
    double time_taken = double(end- start); // time difference
    if(time_taken ==-5){ //condition
	 system("rosnode kill inc_rplidarNode"); //killer command
	}
}


//main function
int main(int argc, char **argv)
{
    ros::init(argc, argv, "node_killer_2");
    ros::NodeHandle n;

    ros::Rate loop_rate(10); // frequency rate
    ros::Subscriber sub = n.subscribe<sensor_msgs::LaserScan>("/new_scan_far", 1000, scanCallback); //subscriber
   
//loop
while(ros::ok()){
	time(&start); //start time
 	timer(); //call timer function
	ros::spinOnce();
	loop_rate.sleep(); //sleep
	}

    return 0;
}

//end
