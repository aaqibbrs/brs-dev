//header

#include <ros/ros.h>
#include <std_msgs/Int32.h>
#include <iostream>
#include <stdio.h>
#include <unistd.h>
#include <termios.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h> 
#include <stdbool.h>


//function termios
int kbhit(void) {
    static bool initflag = false;
    static const int STDIN = 0;

    if (!initflag) {
        // Use termios to turn off line buffering
        struct termios term;
        tcgetattr(STDIN, &term);
        term.c_lflag &= ~ICANON;
        tcsetattr(STDIN, TCSANOW, &term);
        setbuf(stdin, NULL);
        initflag = true;
    }

    int nbbytes;
    ioctl(STDIN, FIONREAD, &nbbytes); 
    return nbbytes;
}

//main function
int main(int argc, char** argv) {
ros::init(argc, argv, "node_restart");
  ros::NodeHandle n;
int count=0;
char c;
//loop
while (!kbhit()) {
//	if(count<5)
	//{    
//	for(;;)   {
   	system("roslaunch karcher rplidar.launch"); //node launcher
//	system("roslaunch karcher rplidar1.launch");
   	//system("roslaunch rplidar_ros rplidar_ros.launch"); //node launcher
   	//count++;
	c=getchar(); 
	}
  // }
    
 }
   	//end
